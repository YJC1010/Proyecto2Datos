# tiny-sql-client.ps1
function Execute-MyQuery {
    param(
        [string]$QueryFile,
        [string]$IP,
        [int]$Port
    )

    # Leer las consultas del archivo
    $queries = Get-Content $QueryFile

    foreach ($query in $queries) {
        Write-Host "Consultando: $query" # Imprime la consulta que se est� leyendo
        # Crear un objeto JSON que contenga la consulta
        $queryObject = @{ Query = $query.Trim() }  # Aseg�rate de recortar espacios en blanco
        $jsonQuery = $queryObject | ConvertTo-Json  # Convertir el objeto a JSON

        # Agrega esta l�nea para imprimir el JSON que se est� enviando
        Write-Host "Enviando JSON: $jsonQuery"

        # Enviar la consulta JSON al servidor
        $client = New-Object System.Net.Sockets.TcpClient($IP, $Port)
        $stream = $client.GetStream()
        $writer = New-Object System.IO.StreamWriter($stream)

        # Enviar como JSON
        $writer.WriteLine($jsonQuery) 
        $writer.Flush()

        # Leer la respuesta
        $reader = New-Object System.IO.StreamReader($stream)
        $response = $reader.ReadToEnd()
        Write-Host "Respuesta del servidor: $response"

        $client.Close()
    }
}


