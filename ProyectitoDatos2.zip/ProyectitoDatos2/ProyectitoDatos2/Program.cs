﻿using System;
using ProyectitoDatos2.Server.APIInterface; // Importar el espacio de nombres correcto

class Program
{
    static void Main(string[] args)
    {
        // Crear instancia del servidor con IP y puerto
        string ipAddress = "127.0.0.1";
        int port = 8000;

        ApiInterface apiInterface = new ApiInterface(ipAddress, port);
        apiInterface.Start();

        // Mantener el servidor en ejecución
        Console.WriteLine("Servidor en ejecución. Presione cualquier tecla para detenerlo...");
        Console.ReadKey();
    }
}
