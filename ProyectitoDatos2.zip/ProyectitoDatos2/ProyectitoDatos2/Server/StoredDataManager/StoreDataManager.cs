﻿using System.IO;

namespace ProyectitoDatos2.Server.StoredDataManager
{
    public class StoredDataManager
    {
        public void CreateDatabase(string databaseName)
        {
            string databasePath = Path.Combine("Databases", databaseName);
            if (!Directory.Exists(databasePath))
            {
                Directory.CreateDirectory(databasePath);
            }
        }

        // Métodos para manejar tablas, índices y datos
    }
}