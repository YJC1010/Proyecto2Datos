﻿using ProyectitoDatos2.Server.APIInterface;

namespace ProyectitoDatos2.Server.QueryProcessor
{
    public class QueryProcessor
    {
        public QueryResponse ProcessQuery(QueryRequest request)
        {
            // Lógica de procesamiento de la consulta
            if (request.Query.StartsWith("CREATE DATABASE"))
            {
                return new QueryResponse
                {
                    Success = true,
                    Message = "Database created successfully."
                };
            }

            return new QueryResponse
            {
                Success = false,
                Message = "Unsupported query."
            };
        }
    }
}