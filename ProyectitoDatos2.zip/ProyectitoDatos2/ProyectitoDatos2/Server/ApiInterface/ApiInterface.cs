﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using ProyectitoDatos2.Server.QueryProcessor;
using ProyectitoDatos2.Server.APIInterface;

namespace ProyectitoDatos2.Server.APIInterface
{
    public class ApiInterface
    {
        private TcpListener _server;
        private bool _isRunning;

        public ApiInterface(string ipAddress, int port)
        {
            _server = new TcpListener(IPAddress.Parse(ipAddress), port);
        }

        public void Start()
        {
            _server.Start();
            _isRunning = true;
            Console.WriteLine("Server started...");
            Task.Run(() => ListenForClients());
        }

        private async Task ListenForClients()
        {
            while (_isRunning)
            {
                TcpClient client = await _server.AcceptTcpClientAsync();
                // Guardamos la tarea pero no la esperamos
                Task clientHandlerTask = HandleClient(client);
            }
        }

        private async Task HandleClient(TcpClient client)
        {
            try
            {
                NetworkStream stream = client.GetStream();
                byte[] buffer = new byte[1024];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string requestJson = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                Console.WriteLine($"Consulta recibida: {requestJson}"); // Aquí imprime la consulta cruda

                // Intenta deserializar y verifica si hay problemas
                try
                {
                    string responseJson = ProcessRequest(requestJson);
                    byte[] responseBytes = Encoding.UTF8.GetBytes(responseJson);
                    await stream.WriteAsync(responseBytes, 0, responseBytes.Length);
                }
                catch (JsonException jsonEx)
                {
                    Console.WriteLine($"Error al procesar JSON: {jsonEx.Message}"); // Imprime errores de JSON
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al manejar el cliente: {ex.Message}");
            }
            finally
            {
                client.Close();
            }
        }



        private string ProcessRequest(string requestJson)
        {
            // Convertir JSON a objeto de tipo QueryRequest
            var request = JsonConvert.DeserializeObject<QueryRequest>(requestJson);

            if (request == null || string.IsNullOrEmpty(request.Query))
            {
                return JsonConvert.SerializeObject(new QueryResponse
                {
                    Success = false,
                    Message = "Invalid request format."
                });
            }

            var response = new ProyectitoDatos2.Server.QueryProcessor.QueryProcessor().ProcessQuery(request);
            return JsonConvert.SerializeObject(response);
        }


    }

    public class QueryRequest
    {
        public string Query { get; set; } = string.Empty; // Inicialización a un valor no nulo

        // Puedes agregar un constructor opcional si necesitas personalizar la inicialización
        public QueryRequest(string query)
        {
            Query = query ?? throw new ArgumentNullException(nameof(query));
        }
    }




    public class QueryResponse
    {
        public bool Success { get; set; }
        public string? Message { get; set; } // Permitir nulo
        public object? Data { get; set; }    // Permitir nulo
    }

}