param (
    [Parameter(Mandatory = $true)]
    [string]$QueryFile,  # Archivo SQL
    [Parameter(Mandatory = $true)]
    [string]$IP,         # Direcci�n IP del servidor
    [Parameter(Mandatory = $true)]
    [int]$Port           # Puerto del servidor
)

$ipEndPoint = [System.Net.IPEndPoint]::new([System.Net.IPAddress]::Parse($IP), $Port)

# Funci�n para enviar un mensaje al servidor
function Send-Message {
    param (
        [Parameter(Mandatory=$true)]
        [pscustomobject]$message,
        [Parameter(Mandatory=$true)]
        [System.Net.Sockets.Socket]$client
    )
    $stream = New-Object System.Net.Sockets.NetworkStream($client)
    $writer = New-Object System.IO.StreamWriter($stream)
    try {
        $writer.WriteLine($message)
    }
    finally {
        $writer.Close()
        $stream.Close()
    }
}

# Funci�n para recibir un mensaje del servidor
function Receive-Message {
    param (
        [System.Net.Sockets.Socket]$client
    )
    $stream = New-Object System.Net.Sockets.NetworkStream($client)
    $reader = New-Object System.IO.StreamReader($stream)
    try {
        return $reader.ReadLine()
    }
    finally {
        $reader.Close()
        $stream.Close()
    }
}

# Funci�n principal para ejecutar las consultas SQL
function Execute-MyQuery {
    param (
        [string]$QueryFile,
        [string]$IP,
        [int]$Port
    )
    
    # Lee las sentencias del archivo SQL
    $queries = Get-Content $QueryFile -Raw -split ";"
    foreach ($query in $queries) {
        if ($query -ne "") {
            # Crear socket y conectar al servidor
            $client = New-Object System.Net.Sockets.Socket($ipEndPoint.AddressFamily, 
                                    [System.Net.Sockets.SocketType]::Stream, 
                                    [System.Net.Sockets.ProtocolType]::Tcp)
            $client.Connect($ipEndPoint)

            $requestObject = [PSCustomObject]@{
                RequestType = 0;
                RequestBody = $query.Trim()
            }
            $jsonMessage = ConvertTo-Json -InputObject $requestObject -Compress
            Write-Host -ForegroundColor Green "Enviando comando: $query"
            Send-Message -client $client -message $jsonMessage
            
            # Recibir respuesta
            $response = Receive-Message -client $client
            $responseObject = ConvertFrom-Json -InputObject $response
            
            # Mostrar resultado en tabla
            $responseObject | Format-Table
            Write-Host -ForegroundColor Green "Respuesta recibida: $response"
            
            # Cerrar la conexi�n
            $client.Shutdown([System.Net.Sockets.SocketShutdown]::Both)
            $client.Close()
        }
    }
}

# This is an example, should not be called here
Send-SQLCommand -command "CREATE TABLE ESTUDIANTE"
Send-SQlCommand -command "SELECT * FROM ESTUDIANTE"