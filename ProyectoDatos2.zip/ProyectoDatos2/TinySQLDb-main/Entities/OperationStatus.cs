﻿namespace Entities
{
    public enum OperationStatus
    {
        Success,
        Error,
        NotFound,
        InvalidRequest
    }
}
