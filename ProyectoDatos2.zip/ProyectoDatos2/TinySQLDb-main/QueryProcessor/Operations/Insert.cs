﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueryProcessor.Operations
{
    internal class Insert
    {
        internal OperationStatus Execute(string tableName, Dictionary<string, object> values)
        {
            return Store.GetInstance().Insert(tableName, values);
        }
    }
}
