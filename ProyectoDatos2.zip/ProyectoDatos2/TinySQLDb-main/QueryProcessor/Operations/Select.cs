﻿using Entities;
using StoreDataManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System;
using System.Collections.Generic;
using System.IO;

namespace QueryProcessor.Operations
{
    public class Select
    {
        public OperationStatus Execute(string sentence)
        {
            string tableName = ExtractTableName(sentence);
            string whereClause = ExtractWhereClause(sentence);
            string[] selectedColumns = ExtractColumns(sentence);

            string tablePath = Path.Combine(DataPath, Store.GetInstance().GetCurrentDatabase(), $"{tableName}.table");

            if (!File.Exists(tablePath))
            {
                return OperationStatus.TableNotFound;
            }

            List<object[]> results = new List<object[]>();

            using (FileStream stream = File.Open(tablePath, FileMode.Open))
            using (BinaryReader reader = new BinaryReader(stream))
            {
                while (stream.Position < stream.Length)
                {
                    object[] rowData = ReadRowData(reader);
                    if (ApplyWhereClause(rowData, whereClause))
                    {
                        results.Add(rowData);
                    }
                }
            }

            PrintResults(results, selectedColumns);
            return OperationStatus.Success;
        }

        private object[] ReadRowData(BinaryReader reader)
        {
            // Asumiendo que cada fila tiene una estructura fija
            int id = reader.ReadInt32();
            string name = reader.ReadString().TrimEnd();
            string surname = reader.ReadString().TrimEnd();
            DateTime birthDate = DateTime.Parse(reader.ReadString());

            return new object[] { id, name, surname, birthDate };
        }

        private bool ApplyWhereClause(object[] rowData, string whereClause)
        {
            // Lógica para evaluar la cláusula WHERE
            // Ejemplo simple para ID
            if (whereClause.StartsWith("ID = "))
            {
                int value = int.Parse(whereClause.Split('=')[1].Trim());
                return (int)rowData[0] == value; // Compara con el ID
            }
            // Agregar más condiciones según sea necesario
            return true; // Si no hay condiciones, devuelve true
        }

        private void PrintResults(List<object[]> results, string[] selectedColumns)
        {
            foreach (var row in results)
            {
                foreach (var column in selectedColumns)
                {
                    if (column == "*")
                    {
                        Console.Write(string.Join("\t", row));
                    }
                    else
                    {
                        // Suponiendo que los nombres de columnas están en orden
                        int index = Array.IndexOf(new[] { "ID", "Name", "Surname", "BirthDate" }, column);
                        if (index != -1)
                        {
                            Console.Write(row[index] + "\t");
                        }
                    }
                }
                Console.WriteLine();
            }
        }

        private string ExtractTableName(string sentence)
        {
            // Suponiendo que la tabla está después de FROM
            var parts = sentence.Split(new[] { "FROM" }, StringSplitOptions.RemoveEmptyEntries);
            return parts.Length > 1 ? parts[1].Split(' ')[0].Trim() : throw new InvalidRequestException();
        }

        private string[] ExtractColumns(string sentence)
        {
            // Suponiendo que las columnas están antes de FROM
            var parts = sentence.Split(new[] { "FROM" }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length > 0)
            {
                return parts[0].Replace("SELECT", "").Split(',').Select(c => c.Trim()).ToArray();
            }
            return new[] { "*" }; // Si no se especifican columnas, seleccionar todo
        }

        private string ExtractWhereClause(string sentence)
        {
            // Suponiendo que la cláusula WHERE está al final
            var parts = sentence.Split(new[] { "WHERE" }, StringSplitOptions.RemoveEmptyEntries);
            return parts.Length > 1 ? parts[1].Trim() : string.Empty;
        }
    }
}

