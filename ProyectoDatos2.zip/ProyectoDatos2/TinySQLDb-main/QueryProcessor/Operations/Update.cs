using System;
using System.Collections.Generic;
using System.IO;

namespace QueryProcessor.Operations
{
    public class Update
    {
        public OperationStatus Execute(string sentence)
        {
            string tableName = ExtractTableName(sentence);
            string columnName = ExtractColumnName(sentence);
            object newValue = ExtractNewValue(sentence);
            string whereClause = ExtractWhereClause(sentence);

            string tablePath = Path.Combine(DataPath, Store.GetInstance().GetCurrentDatabase(), $"{tableName}.table");

            if (!File.Exists(tablePath))
            {
                return OperationStatus.TableNotFound;
            }

            List<long> positionsToUpdate = new List<long>();

            // Buscar filas a actualizar
            using (FileStream stream = File.Open(tablePath, FileMode.Open))
            using (BinaryReader reader = new BinaryReader(stream))
            {
                while (stream.Position < stream.Length)
                {
                    long position = stream.Position;
                    var rowData = ReadRowData(reader);

                    if (ApplyWhereClause(rowData, whereClause))
                    {
                        positionsToUpdate.Add(position);
                    }
                }
            }

            // Actualizar registros
            using (FileStream stream = File.Open(tablePath, FileMode.Open))
            using (BinaryWriter writer = new BinaryWriter(stream))
            {
                foreach (var position in positionsToUpdate)
                {
                    stream.Position = position;
                    WriteRowData(writer, newValue, columnName);
                }
            }

            return OperationStatus.Success;
        }

        private object[] ReadRowData(BinaryReader reader)
        {
            int id = reader.ReadInt32();
            string name = reader.ReadString().TrimEnd();
            string surname = reader.ReadString().TrimEnd();
            DateTime birthDate = DateTime.Parse(reader.ReadString());

            return new object[] { id, name, surname, birthDate };
        }

        private void WriteRowData(BinaryWriter writer, object newValue, string columnName)
        {
            // Escribe la fila de datos, actualizando solo la columna indicada
            writer.Write((int)newValue); // Suponiendo que estamos actualizando ID
            // Implementar l�gica para escribir otros campos seg�n sea necesario
            // Por ejemplo, si columnName == "Name", se actualiza el nombre
        }

        private bool ApplyWhereClause(object[] rowData, string whereClause)
        {
            // L�gica para evaluar la cl�usula WHERE
            if (whereClause.StartsWith("ID = "))
            {
                int value = int.Parse(whereClause.Split('=')[1].Trim());
                return (int)rowData[0] == value; // Compara con el ID
            }
            // Otras condiciones seg�n sea necesario
            return true; // Si no hay condiciones, devuelve true
        }

        private string ExtractTableName(string sentence)
        {
            var parts = sentence.Split(new[] { "UPDATE" }, StringSplitOptions.RemoveEmptyEntries);
            return parts.Length > 1 ? parts[1].Split(' ')[0].Trim() : throw new InvalidRequestException();
        }

        private string ExtractColumnName(string sentence)
        {
            var parts = sentence.Split(new[] { "SET" }, StringSplitOptions.RemoveEmptyEntries);
            return parts.Length > 1 ? parts[1].Split('=')[0].Trim() : throw new InvalidRequestException();
        }

        private object ExtractNewValue(string sentence)
        {
            var parts = sentence.Split(new[] { "SET" }, StringSplitOptions.RemoveEmptyEntries);
            var columnParts = parts[1].Split('=');
            return Convert.ChangeType(columnParts[1].Trim(), typeof(int)); // Cambia seg�n el tipo
        }

        private string ExtractWhereClause(string sentence)
        {
            var parts = sentence.Split(new[] { "WHERE" }, StringSplitOptions.RemoveEmptyEntries);
            return parts.Length > 1 ? parts[1].Trim() : string.Empty;
        }
    }
}
