﻿using Entities;
using QueryProcessor.Exceptions;
using QueryProcessor.Operations;
using StoreDataManager;

namespace QueryProcessor
{
    public class SQLQueryProcessor
    {
        public static OperationStatus Execute(string sentence)
        {
            /// The following is example code. Parser should be called
            /// on the sentence to understand and process what is requested
            string trimmedSentence = sentence.Trim().ToUpperInvariant();

            if (sentence.StartsWith("CREATE DATABASE"))
            {
                string dbName = ExtractDatabaseName(sentence);
                return new CreateDatabase().Execute(dbName);
            }
            else if (sentence.StartsWith("SET DATABASE"))
            {
                string dbName = ExtractDatabaseName(sentence);
                return new SetDatabase().Execute(dbName);
            }
            else if (sentence.StartsWith("CREATE TABLE"))
            {
                string tableName = ExtractTableName(sentence);
                return new CreateTable().Execute(tableName);
            }
            else if (sentence.StartsWith("INSERT INTO"))
            {
                return new Insert().Execute(sentence);
            }
            else if (sentence.StartsWith("UPDATE"))
            {
                return new Update().Execute(sentence);
            }
            else if (sentence.StartsWith("DELETE"))
            {
                return new Delete().Execute(sentence);
            }
            else if (sentence.StartsWith("SELECT"))
            {
                return new Select().Execute(sentence);
            }
            else
            {
                throw new UnknownSQLSentenceException();
            }
        }

        private static string ExtractDatabaseName(string sentence)
        {
            var parts = sentence.Split(' ');
            return parts.Length > 2 ? parts[2].Trim() : throw new InvalidRequestException();
        }
        private static (string tableName, Dictionary<string, object> values) ParseInsertStatement(string sentence)
        {
            // Implementar análisis para extraer el nombre de la tabla y los valores
            var parts = sentence.Split(new[] { "VALUES" }, StringSplitOptions.None);
            var tablePart = parts[0].Trim();
            var valuePart = parts[1].Trim();

            var tableName = tablePart.Split(' ')[2]; // ESTUDIANTES
            var values = new Dictionary<string, object>();

            // Extraer columnas
            var columns = tablePart.Substring(tablePart.IndexOf('(') + 1, tablePart.IndexOf(')') - tablePart.IndexOf('(') - 1)
                              .Split(',').Select(c => c.Trim()).ToArray();

            // Extraer valores
            var valueArray = valuePart.Trim().Trim('(', ')').Split(',');
            for (int i = 0; i < columns.Length; i++)
            {
                values[columns[i]] = valueArray[i].Trim().Trim('\''); // Eliminar comillas
            }

            return (tableName, values);
        }

        private static (string tableName, Dictionary<string, object> setValues, string whereClause) ParseUpdateStatement(string sentence)
        {
            // Implementar análisis para extraer el nombre de la tabla, los valores a actualizar y la cláusula WHERE
            var parts = sentence.Split(new[] { "SET", "WHERE" }, StringSplitOptions.None);
            var tableName = parts[0].Trim().Split(' ')[1]; // ESTUDIANTES
            var setValues = new Dictionary<string, object>();

            // Extraer valores a actualizar
            var setPart = parts[1].Trim();
            var setArray = setPart.Split(',').Select(s => s.Trim()).ToArray();

            foreach (var item in setArray)
            {
                var keyValue = item.Split('=');
                setValues[keyValue[0].Trim()] = keyValue[1].Trim().Trim('\''); // Eliminar comillas
            }

            var whereClause = parts.Length > 2 ? parts[2].Trim() : string.Empty;

            return (tableName, setValues, whereClause);
        }

        private static (string tableName, string whereClause) ParseDeleteStatement(string sentence)
        {
            // Implementar análisis para extraer el nombre de la tabla y la cláusula WHERE
            var parts = sentence.Split(new[] { "WHERE" }, StringSplitOptions.None);
            var tableName = parts[0].Trim().Split(' ')[2]; // ESTUDIANTES
            var whereClause = parts.Length > 1 ? parts[1].Trim() : string.Empty;

            return (tableName, whereClause);
        }
    }
    public class SetDatabase
    {
        public OperationStatus Execute(string databaseName)
        {
            if (Store.GetInstance().DatabaseExists(databaseName))
            {
                Store.GetInstance().SetCurrentDatabase(databaseName);
                return OperationStatus.Success;
            }
            else
            {
                return OperationStatus.DatabaseNotFound;
            }
        }
    }

}
