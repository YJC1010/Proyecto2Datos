using System;
using System.IO;

namespace ApiInterface.Operations
{
    public class CreateDatabase
    {
        public OperationStatus Execute(string databaseName)
        {
            return Store.GetInstance().CreateDatabase(databaseName);
        }
    }
}