﻿using Entities;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace StoreDataManager
{
    public sealed class Store
    {
        private static Store? instance = null;
        private static readonly object _lock = new object();
        private string CurrentDatabase { get; set; } = string.Empty;

        public static Store GetInstance()
        {
            lock(_lock)
            {
                if (instance == null) 
                {
                    instance = new Store();
                }
                return instance;
            }
        }

        private const string DatabaseBasePath = @"C:\TinySql\";
        private const string DataPath = $@"{DatabaseBasePath}\Data";
        private const string SystemCatalogPath = $@"{DataPath}\SystemCatalog";
        private const string SystemDatabasesFile = $@"{SystemCatalogPath}\SystemDatabases.table";
        private const string SystemTablesFile = $@"{SystemCatalogPath}\SystemTables.table";

        public Store()
        {
            this.InitializeSystemCatalog();
            
        }

        private void InitializeSystemCatalog()
        {
            // Always make sure that the system catalog and above folder
            // exist when initializing
            Directory.CreateDirectory(SystemCatalogPath);
        }
        public OperationStatus CreateDatabase(string databaseName)
        {
            string dbPath = Path.Combine(DataPath, databaseName);
            if (!Directory.Exists(dbPath))
            {
                Directory.CreateDirectory(dbPath);
                RegisterDatabaseInSystemCatalog(databaseName);
                return OperationStatus.Success;
            }
            return OperationStatus.DatabaseExists;
        }
        private void RegisterDatabaseInSystemCatalog(string databaseName)
        {
            string catalogPath = Path.Combine(SystemCatalogPath, "SystemDatabases.table");
            using (FileStream stream = File.Open(catalogPath, FileMode.Append))
            using (BinaryWriter writer = new BinaryWriter(stream))
            {
                writer.Write(databaseName.PadRight(30));
            }
        }

        // Método para insertar datos en una tabla
        public OperationStatus Insert(string tableName, object[] values)
        {
            string tablePath = Path.Combine(DataPath, CurrentDatabase, $"{tableName}.table");
            using (FileStream stream = File.Open(tablePath, FileMode.Append))
            using (BinaryWriter writer = new BinaryWriter(stream))
            {
                // Escribir los valores en el archivo binario
                foreach (var value in values)
                {
                    if (value is int)
                        writer.Write((int)value);
                    else if (value is string)
                        writer.Write(((string)value).PadRight(30));
                    // Añadir otros tipos de datos según sea necesario
                }
            }
            return OperationStatus.Success;
        }

        public OperationStatus CreateTable(string tableName, List<ColumnDefinition> columns)
        {
            string tablePath = Path.Combine(DataPath, Store.GetInstance().GetCurrentDatabase(), $"{tableName}.table");
            using (FileStream stream = File.Open(tablePath, FileMode.CreateNew))
            using (BinaryWriter writer = new BinaryWriter(stream))
            {
                // Escribir la definición de la tabla (columnas y tipos)
                foreach (var column in columns)
                {
                    writer.Write(column.Name.PadRight(30));
                    writer.Write((int)column.Type); // Grabar el tipo de dato de la columna
                }
            }
            return OperationStatus.Success;
        }


        public OperationStatus Select()
        {
            // Creates a default Table called ESTUDIANTES
            var tablePath = $@"{DataPath}\TESTDB\ESTUDIANTES.Table";
            using (FileStream stream = File.Open(tablePath, FileMode.OpenOrCreate))
            using (BinaryReader reader = new(stream))
            {
                // Print the values as a I know exactly the types, but this needs to be done right
                Console.WriteLine(reader.ReadInt32());
                Console.WriteLine(reader.ReadString());
                Console.WriteLine(reader.ReadString());
                return OperationStatus.Success;
            }
        }
        public OperationStatus Insert(string tableName, Dictionary<string, object> values)
        {
            var tablePath = $@"{DataPath}\TESTDB\{tableName}.Table";

            using (FileStream stream = new FileStream(tablePath, FileMode.Append))
            using (BinaryWriter writer = new BinaryWriter(stream))
            {
                foreach (var value in values.Values)
                {
                    writer.Write(value.ToString().PadRight(50)); // Ajustar el tamaño según tu estructura
                }
            }
            return OperationStatus.Success;
        }
        public OperationStatus Update(string tableName, Dictionary<string, object> setValues, string whereClause)
        {
            var tablePath = $@"{DataPath}\TESTDB\{tableName}.Table";
            // Lógica para leer la tabla y aplicar la cláusula WHERE para actualizar los registros.
            List<string[]> records = new List<string[]>();

            using (FileStream stream = new FileStream(tablePath, FileMode.Open))
            using (BinaryReader reader = new BinaryReader(stream))
            {
                while (stream.Position < stream.Length)
                {
                    // Leer los registros existentes y almacenarlos en la lista.
                    var record = new string[3]; // Asumiendo que hay 3 campos: ID, Nombre, Apellido
                    record[0] = reader.ReadInt32().ToString();
                    record[1] = reader.ReadString().Trim();
                    record[2] = reader.ReadString().Trim();
                    records.Add(record);
                }
            }

            // Actualizar los registros según la cláusula WHERE
            foreach (var record in records)
            {
                if (MatchesWhereClause(record, whereClause))
                {
                    foreach (var keyValue in setValues)
                    {
                        // Aquí se debe implementar la lógica para actualizar el campo correspondiente.
                        // Por ejemplo, si keyValue.Key es "NOMBRE", actualiza record[1]
                        if (keyValue.Key.ToUpper() == "NOMBRE")
                        {
                            record[1] = keyValue.Value.ToString();
                        }
                        // Repetir para otros campos...
                    }
                }
            }

            // Volver a escribir los registros actualizados en el archivo.
            using (FileStream stream = new FileStream(tablePath, FileMode.Create))
            using (BinaryWriter writer = new BinaryWriter(stream))
            {
                foreach (var record in records)
                {
                    writer.Write(int.Parse(record[0]));
                    writer.Write(record[1].PadRight(50)); // Ajustar el tamaño según tu estructura
                    writer.Write(record[2].PadRight(50));
                }
            }

            return OperationStatus.Success;
        }
        public OperationStatus Delete(string tableName, string whereClause)
        {
            string tablePath = Path.Combine(DataPath, Store.GetInstance().GetCurrentDatabase(), $"{tableName}.table");

            if (!File.Exists(tablePath))
            {
                return OperationStatus.TableNotFound;
            }

            List<long> positionsToDelete = new List<long>();

            using (FileStream stream = File.Open(tablePath, FileMode.Open))
            using (BinaryReader reader = new BinaryReader(stream))
            {
                while (stream.Position < stream.Length)
                {
                    var position = stream.Position;
                    var rowData = ReadRowData(reader);

                    if (ApplyWhereClause(rowData, whereClause))
                    {
                        positionsToDelete.Add(position);
                    }
                }
            }

            // Crear un nuevo archivo sin las filas eliminadas
            string tempPath = Path.Combine(DataPath, Store.GetInstance().GetCurrentDatabase(), "temp.table");
            using (FileStream tempStream = File.Open(tempPath, FileMode.Create))
            using (BinaryWriter writer = new BinaryWriter(tempStream))
            {
                using (FileStream originalStream = File.Open(tablePath, FileMode.Open))
                using (BinaryReader originalReader = new BinaryReader(originalStream))
                {
                    while (originalStream.Position < originalStream.Length)
                    {
                        var position = originalStream.Position;
                        var rowData = ReadRowData(originalReader);

                        if (!positionsToDelete.Contains(position))
                        {
                            WriteRowData(writer, rowData);
                        }
                    }
                }
            }

            // Reemplazar el archivo original
            File.Delete(tablePath);
            File.Move(tempPath, tablePath);

            return OperationStatus.Success;
        }

        public OperationStatus DropTable(string tableName)
        {
            string tablePath = Path.Combine(DataPath, CurrentDatabase, $"{tableName}.table");
            if (File.Exists(tablePath))
            {
                File.Delete(tablePath);
                return OperationStatus.Success;
            }
            return OperationStatus.TableNotFound;
        }
        private bool MatchesWhereClause(string[] record, string whereClause)
        {
            // La cláusula WHERE puede ser del tipo "ID = 1" o "NOMBRE = 'Isaac'"
            var condition = whereClause.Split(new[] { ' ', '=' }, StringSplitOptions.RemoveEmptyEntries);

            if (condition.Length != 2)
            {
                return false; // La cláusula no es válida
            }

            var columnName = condition[0].Trim().ToUpper(); // "ID" o "NOMBRE"
            var value = condition[1].Trim().Trim('\''); // Eliminar comillas simples

            switch (columnName)
            {
                case "ID":
                    return record[0] == value; // Asumiendo que record[0] es el ID
                case "NOMBRE":
                    return record[1].Equals(value, StringComparison.OrdinalIgnoreCase); // Comparación sin distinción de mayúsculas
                case "APELLIDO":
                    return record[2].Equals(value, StringComparison.OrdinalIgnoreCase); // Comparación sin distinción de mayúsculas
                default:
                    return false; // Si la columna no es válida
            }
        }
        

        public void SetCurrentDatabase(string databaseName)
        {
            CurrentDatabase = databaseName;
        }

        public string GetCurrentDatabase()
        {
            return CurrentDatabase;
        }
        public enum IndexType
        {
            BTREE,
            BST
        }

        public class Index
        {
            public string IndexName { get; set; }
            public string TableName { get; set; }
            public string ColumnName { get; set; }
            public IndexType Type { get; set; }
            public Dictionary<object, long> IndexData { get; set; } // Mapa de valores a posiciones de archivo

            public Index(string indexName, string tableName, string columnName, IndexType type)
            {
                IndexName = indexName;
                TableName = tableName;
                ColumnName = columnName;
                Type = type;
                IndexData = new Dictionary<object, long>();
            }
        }

        public class CreateIndex
        {
            public OperationStatus Execute(string indexName, string tableName, string columnName, IndexType type)
            {
                // Verifica si la tabla existe
                if (!Store.GetInstance().TableExists(tableName))
                {
                    return OperationStatus.TableNotFound;
                }

                // Crea el índice
                Index newIndex = new Index(indexName, tableName, columnName, type);
                Store.GetInstance().CreateIndex(newIndex);

                // Registra el índice en el SystemCatalog
                RegisterIndexInSystemCatalog(newIndex);
                return OperationStatus.Success;
            }

            private void RegisterIndexInSystemCatalog(Index index)
            {
                string catalogPath = Path.Combine(SystemCatalogPath, "SystemIndexes.table");
                using (FileStream stream = File.Open(catalogPath, FileMode.Append))
                using (BinaryWriter writer = new BinaryWriter(stream))
                {
                    writer.Write(index.IndexName.PadRight(30));
                    writer.Write(index.TableName.PadRight(30));
                    writer.Write(index.ColumnName.PadRight(30));
                    writer.Write((int)index.Type);
                }
            }
        }
    }
}
