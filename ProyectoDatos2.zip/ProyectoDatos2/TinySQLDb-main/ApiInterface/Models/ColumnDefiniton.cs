namespace ApiInterface.InternalModels
{
    public class ColumnDefinition
    {
        public string Name { get; set; }   // Nombre de la columna
        public DataType Type { get; set; }  // Tipo de dato de la columna

        public ColumnDefinition(string name, DataType type)
        {
            Name = name;
            Type = type;
        }
    }

    public enum DataType
    {
        INTEGER,
        DOUBLE,
        VARCHAR,
        DATETIME
    }
}