﻿using ApiInterface;

await Server.Start();
