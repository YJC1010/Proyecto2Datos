﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiInterface.Exceptions
{
    internal class UnknowRequestTypeException : Exception
    {
        public UnknowRequestTypeException() : base("El tipo de solicitud es desconocido.")
        {
        }

        public UnknowRequestTypeException(string message) : base(message)
        {
        }

        public UnknowRequestTypeException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
