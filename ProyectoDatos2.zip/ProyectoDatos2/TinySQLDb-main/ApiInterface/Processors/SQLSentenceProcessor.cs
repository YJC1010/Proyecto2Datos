﻿using ApiInterface.InternalModels;
using ApiInterface.Models;
using Entities;
using QueryProcessor;

namespace ApiInterface.Processors
{
    internal class SQLSentenceProcessor(Request request) : IProcessor 
    {
        public Request Request { get; } = request;

        public SQLSentenceProcessor(Request request)
        {
            Request = request;
        }


        public Response Process()
        {
            try
            {
                var sentence = this.Request.RequestBody;
                var result = SQLQueryProcessor.Execute(sentence);
                return ConvertToResponse(result);
            }
            catch (Exception ex)
            {
                // Manejo de excepciones y creación de una respuesta de error
                return new Response
                {
                    Status = OperationStatus.Error, // o el estado que corresponda
                    Request = this.Request,
                    ResponseBody = ex.Message
                };
            }
        }

        private Response ConvertToResponse(OperationStatus result)
        {
            return new Response
            {
                Status = result,
                Request = this.Request,
                ResponseBody = string.Empty
            };
        }
    }
}
